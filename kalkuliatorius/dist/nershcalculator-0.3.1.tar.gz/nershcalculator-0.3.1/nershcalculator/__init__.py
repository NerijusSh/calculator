"""Calculator module"""
from nershcalculator.nershcalculator import Calculator

__version__ = "0.3.1"